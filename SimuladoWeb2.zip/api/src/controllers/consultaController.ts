// src/controllers/ConsultaController.ts
import { Request, Response } from 'express';
import prisma from '@prisma/client';

export const registrarConsulta = async (req: Request, res: Response) => {
  try {
    const novaConsulta = await prisma.consulta.create({
      data: req.body,
    });
    res.json(novaConsulta);
  } catch (error) {
    console.error(error);
    res.status(500).json({ erro: 'Erro ao registrar consulta.' });
  }
};

// Implemente outras operações CRUD para Consulta aqui.