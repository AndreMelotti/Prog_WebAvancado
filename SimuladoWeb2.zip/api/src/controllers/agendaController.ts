// src/controllers/AgendaController.ts
import { Request, Response } from 'express';
import prisma from '@prisma/client';

export const criarAgenda = async (req: Request, res: Response) => {
  try {
    const novaAgenda = await prisma.agenda.create({
      data: req.body,
    });
    res.json(novaAgenda);
  } catch (error) {
    console.error(error);
    res.status(500).json({ erro: 'Erro ao criar agenda.' });
  }
};

// Implemente outras operações CRUD para Agenda aqui.