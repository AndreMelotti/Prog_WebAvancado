// src/controllers/pacienteController.ts
import { Request, Response } from 'express';
import prisma from '@prisma/client';
import PacienteServices from '../services/pacienteServices'


export const criarPaciente = async (req: Request, res: Response) => {
  try {
    const novoPaciente = await prisma.paciente.create({
      data: req.body, // Certifique-se de que sua requisição envia os dados corretos.
    });
    res.json(novoPaciente);
  } catch (error) {
    console.error(error);
    res.status(500).json({ erro: 'Erro ao criar paciente.' });
  }
};

// Implemente outras operações CRUD para Paciente aqui.