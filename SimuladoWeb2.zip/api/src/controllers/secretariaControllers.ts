// src/controllers/SecretariaController.ts
import { Request, Response } from 'express';
import prisma from '@prisma/client';

export const cadastrarSecretaria = async (req: Request, res: Response) => {
  try {
    const novaSecretaria = await prisma.secretaria.create({
      data: req.body,
    });
    res.json(novaSecretaria);
  } catch (error) {
    console.error(error);
    res.status(500).json({ erro: 'Erro ao cadastrar secretaria.' });
  }
};

// Implemente outras operações CRUD para Secretaria aqui.