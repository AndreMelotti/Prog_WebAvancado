import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

class PacienteServices {
  constructor() {}

  async listarPacientes() {
    try {
      const pacientes = await prisma.paciente.findMany();
      return pacientes;
    } catch (error) {
      console.error("Erro ao listar pacientes:", error);
      throw error;
    }
  }

  async criarPaciente(nomePaciente: string, senha: number, usuarios: string) {
    try {
      const paciente = await prisma.paciente.create({
        data: {
          nomePaciente,
          senha,
          usuarios,
        },
      });
      return paciente;
    } catch (error) {
      console.error("Erro ao criar paciente:", error);
      throw error;
    }
  }

  async atualizarPaciente(id: number, nomePaciente: string, senha: number, usuarios: string) {
    try {
      const paciente = await prisma.paciente.update({
        where: { id },
        data: {
          nomePaciente,
          senha,
          usuarios,
        },
      });
      return paciente;
    } catch (error) {
      console.error("Erro ao atualizar paciente:", error);
      throw error;
    }
  }

  async deletarPaciente(id: number) {
    try {
      await prisma.paciente.delete({
        where: { id },
      });
    } catch (error) {
      console.error("Erro ao deletar paciente:", error);
      throw error;
    }
  }
}

export default new PacienteServices();
