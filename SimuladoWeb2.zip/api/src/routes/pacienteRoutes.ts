// src/routes/PacienteRoutes.ts
import express from 'express';
import { criarPaciente } from '../controllers/pacienteController';
// obterPacientes, obterPacientePorId, atualizarPaciente, excluirPaciente
const router = express.Router();

router.post('/pacientes', criarPaciente);
//router.get('/pacientes', obterPacientes);
//router.get('/pacientes/:id', obterPacientePorId);
//router.patch('/pacientes/:id', atualizarPaciente);
//router.delete('/pacientes/:id', excluirPaciente);

export default router;